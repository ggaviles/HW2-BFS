"""
BMI203: Biocomputing algorithms Winter 2022
Assignment 2: Breadth-first search
"""
import networkx as nx
import matplotlib.pyplot as plt
from graph import Graph


__version__ = "0.1.0"
__author__ = "Giovanni Aviles"

